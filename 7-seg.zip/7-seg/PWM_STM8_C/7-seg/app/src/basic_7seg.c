#include "stm8s.h"

//int was_pressed(int button_number);     //deklarace funkce pro ověřování jestli bylo tlačítko zmáčknuto (was pressed)
void delay(int delay_time);               //deklarace funkce pro zpoždění (delay)
void print_7(int input);

void main(void)
{
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV1);              //dělič 1 => 16MHz                 
    GPIO_Init(GPIOB, GPIO_PIN_ALL, GPIO_MODE_OUT_PP_LOW_SLOW);
    int k = 0;
    for (int k = 0; k < 10; k++);
    {
        print_7(k);
        print_7(10);
        delay(1000);
    }
}

void print_7(int input)
{
    switch (input)
    {

    case 0:
        GPIO_Write(GPIOB, 0b01000000);
        break;
    
    case 1:
        GPIO_Write(GPIOB, 0b11111001);
        break;

    case 2:
        GPIO_Write(GPIOB, 0b10100100);
        break;

    case 3:
        GPIO_Write(GPIOB, 0b10110000);
        break;

    case 4:
        GPIO_Write(GPIOB, 0b10011001);
        break;

    case 5:
        GPIO_Write(GPIOB, 0b10010010);
        break;

    case 6:
        GPIO_Write(GPIOB, 0b10000010);
        break;

    case 7:
        GPIO_Write(GPIOB, 0b11111000);
        break;

    case 8:
        GPIO_Write(GPIOB, 0b10000000);
        break;

    case 9:
        GPIO_Write(GPIOB, 0b10010000);
        break;

    default:
        GPIO_Write(GPIOB, 0b11110111);
        break;
    }
}

void delay(int delay_time)
{
    for (int i = 0; i < delay_time; i++);
}












# PWM_STM8_C
Pulse Width Modulation for STM8 created using Jan Vykydal's (gitlab.com/wykys/stm8-tools) tools

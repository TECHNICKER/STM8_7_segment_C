#include "stm8s.h"

extern int numbers[16] = {0b11000000, 0b11111001, 0b10100100, 0b10110000, 0b10011001, 0b10010010, 0b10000010, 0b11111000, 0b10000000, 0b10010000,/*odsud hex*/ 0b10001000, 0b10000011, 0b11000110, 0b10100001, 0b10000110, 0b10001110};
int iter = 0;

void delay(int delay_time);

INTERRUPT_HANDLER(EXTI_PORTD_IRQHandler, 6)
{
    if (GPIO_ReadInputPin(GPIOD, GPIO_PIN_0) == RESET)
    {
        if (iter > 14)
        {iter = 15;}          
        else
        {iter += 1;}
    }
    if (GPIO_ReadInputPin(GPIOD, GPIO_PIN_2) == RESET)
    {
        if (iter < 1)
        {iter = 0;}          
        else
        {iter -= 1;}
    }
}

void main(void)
{
    CLK_HSIPrescalerConfig(CLK_PRESCALER_HSIDIV8);            
    GPIO_Init(GPIOB, GPIO_PIN_ALL, GPIO_MODE_OUT_PP_LOW_SLOW);
    GPIO_Init(GPIOD, GPIO_PIN_0, GPIO_MODE_IN_FL_IT);
    GPIO_Init(GPIOD, GPIO_PIN_2, GPIO_MODE_IN_FL_IT);
    EXTI_SetExtIntSensitivity(EXTI_PORT_GPIOD, EXTI_SENSITIVITY_FALL_ONLY);
    ITC_SetSoftwarePriority(ITC_IRQ_PORTD, ITC_PRIORITYLEVEL_0);

    enableInterrupts();

    while(1)
    {

        GPIO_Write(GPIOB, numbers[iter]);
        //delay(65000);
        //GPIO_Write(GPIOB, 0b11110111);
        //delay(65000);
        /*iter++;
        if (iter > 15)
        {iter = 0;}*/
    }
}

void delay(int delay_time)
{
    for (uint16_t i = 0; i < delay_time; i++);
}











